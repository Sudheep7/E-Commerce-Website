const express = require("express");
const bodyParser = require("body-parser");
// const { addListener } = require("nodemon");
const mongoose = require("mongoose");

const app = express();
 
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/ecomDB");

const userschema={
    username:{
        type:String,
        required:[true,"enter username"],
        unique:true
    },
    password:{
        type:String,
        required:[true,"enter password"]
    },
    email:{
        type:String,
        required:[true,"enter email"]
    }
}

const usermodel=mongoose.model("account",userschema);
const user1=new usermodel({
    username:"vin",
    password:"vin123",
    email:"vin@gmail.com"
});

// user1.save();


const productschema={
    prodno:{
        type:String,
        required:[true,"enter product number"],
        unique:true
    },

    prodname:{
        type:String,
        required:[true,"enter product name"],
    },
    price:{
        type:String,
        required:[true,"enter price"]
    },
    desc:{
        type:String
    }
    
}

const productmodel=mongoose.model("product",productschema);
const prod1=new productmodel({
    prodno:"4",
    prodname:"Puma Red T-shirt",
    price:"600"
});

//  prod1.save();

const inventoryschema= {
    prodnum:{
        // type:[productschema],

        // type: mongoose.Schema.Types.prodno,
        // type:mongoose.productschema.prodno,
        type:String,

        ref:'product'
        // required:[true,"enter prodnum"]

    },
    size:{
        type:String,
        required:[true,"enter size"]
    },
    stockremaining:{
        type:Number,
        min:0
    }
};
// Create a composite index on field1 and field2
// inventoryschema..createIndex({ "prodid": 1, "size": 1 }, { unique: true });

const inventorymodel=mongoose.model("inventory",inventoryschema);


const invent1=new inventorymodel({
    prodnum:'4',
    size:"s",
    stockremaining:5

});

// invent1.save();




// -------------------------------------------------------------------------------------------------------------------------------------------------



app.get("/",(req,res)=>
{
    res.render("index");


})

var currentprod="0";
var addtoc=[];
var namesincart=[];
var priceincart=[];
var itemsincart=[];
var quantityincart=[]
var sizeincart=[]
// var shouldialert=false;
var errormessage="";
var notinstock=[]
var isuserloggedin=false;

app.get('/link', (req, res) => {
    const linkType = req.query.type;
    currentprod=linkType;
    // Use the linkType to determine which link was pressed
    // You can process different actions based on linkType
    console.log(`Link ${linkType} was pressed.`);
    res.redirect("/products-details")

  });



app.get("/account",(req,res)=>
{
    res.render("account");
})



app.get("/products",(req,res)=>
{
    res.render("products");
    const linkType = req.query.type;
    currentprod=linkType;
    // Use the linkType to determine which link was pressed
    // You can process different actions based on linkType
    //console.log(`Link ${linkType} was pressed.`);
    // if(currentprod>4)
    // {

    // }S
})


app.post("/newuser",(req,res)=>
{
   

    console.log("new user");
    const usern=req.body.username;
    const passw=req.body.password;
    const em=req.body.email;
    var sendornot=0;
    console.log(usern+" "+passw+" "+em);

    async function checkuser ()
    {
        try{
    
            var uniqueuser=  await usermodel.find({username:usern});   

                if(uniqueuser.length==1){
                console.log("inside if")
                sendornot=1;
                res.redirect("/senderror");

                }
                  else
                 {
                usermodel.insertMany({
                       username:usern,
                    password:passw,
                    email:em
                     });
                 }

        }
        catch(error)
        {
            console.log("error occured during sign up")
            console.log(error);  
        }
    }
    checkuser();
    setTimeout(() => {
        if(sendornot==0){
        console.log("redirecting to account");
        res.redirect("/account");
        }
        
     }, 100);
 





})


app.get("/senderror",(req,res)=>{
    res.render("general",{message:"Username already exists"});
})



app.post("/products-details",(req,res)=>
{
   const quan=parseInt(req.body.quan);
     const size=req.body.size;
    
     quantityincart.push(quan);
     sizeincart.push(size);

    console.log("current product selected with quan and size" , currentprod ,  quan, size);
    console.log("quantity in cart "+ (quantityincart));
    console.log("size in cart is "+sizeincart);
    const tobeaddedtocart=currentprod;
    if(tobeaddedtocart){
        addtoc.push(tobeaddedtocart);
    }
    console.log(("inside cart",addtoc));

    

})


app.get("/products-details",(req,res)=>
{
    var desctobesent=''
    var nametobesent=''
    var pricetobesent=''
    if(currentprod>3)
    {
        currentprod="4";
    }
    console.log("prod no " , currentprod);

    async function proddesc ()
    {
        try{
                 
            console.log("product num sent to get description is "+currentprod);
            var namedesc=  await productmodel.find({prodno:currentprod},{desc:1,prodname:1,price:1,_id:0});

            
            // console.log(namedesc);
            namedesc.forEach((de)=>
                {
            // console.log(de.desc),
            desctobesent=de.desc
            nametobesent=de.prodname
            pricetobesent=de.price

                }

             )
           

        }
        catch(error)
        {
            console.log(error);  
        }
    }
    proddesc();

 setTimeout(() => {
    res.render("products-details",{desc:desctobesent,prod:currentprod,name:nametobesent,price:pricetobesent});

 }, 100);

})


app.get("/account",(req,res)=>
{
    res.render("account");

})

app.get("/about",(req,res)=>{
    res.render("about");
})

app.get("/contact",(req,res)=>{
    res.render("contact");
})

app.post("/account",(req,res)=>
{

    const user=req.body.loginusername;
    const pass=req.body.loginpass;
    
    async function isuser ()
    {
        try{
                 
            var nameuser=  await usermodel.find({username:user,password:pass});

            // nameuser.forEach((names)=>
            
            // // namesincart.push(names.prodname) 
            // console.log(names.username+" "+names.password)

            //  )
            
                
            if(nameuser.length!=1)
            {
                console.log("wrong credentials");
            }
            else
            {
                console.log("user has logged in")
                isuserloggedin=true;
                res.redirect("/");

            }

        }
        catch(error)
        {
            console.log(error);  
        }
    }
    isuser();
})


app.get("/cart",(req,res)=>
{

  
     itemsincart=addtoc;
     namesincart=[],
     priceincart=[],
    console.log("the items in cart are " , itemsincart);

    for(var i=0;i<addtoc.length;i++)
    {
        
        async  function addinarray()
        {
            try{
                
                var nameinarr=  await productmodel.find({prodno:addtoc[i]},{prodname:1,_id:0});

                nameinarr.forEach((names)=>
                
                namesincart.push(names.prodname)

                 )
                    

            }
            catch(error)
            {
                console.log(error);
            }
        }
        addinarray();

       

    }


    for(var i=0;i<addtoc.length;i++)
    {
        
        async  function addinpricearray()
        {
            try{
                
                  
                    var priceinarr=  await productmodel.find({prodno:addtoc[i]},{price:1,_id:0});

                    priceinarr.forEach((pri)=>{
                    console.log("the price is "+pri.price +" for index in array " )
                    // namesincart.push(pri.price)
                    priceincart.push(pri.price)
                }
    
                     )

            }
            catch(error)
            {
                console.log(error);
            }
        }
        addinpricearray();


    }

    // setInterval(() => {
        res.redirect("/addprice");
    // }, 100);
        


})


app.get("/addprice",(req,res)=>
{
    



    // console.log(namesincart[0].prodname +"is the name");
    // function rendering(){
      res.render("cart",{items:itemsincart,name:namesincart,price:priceincart,size:sizeincart,quantity:quantityincart,errormessage:errormessage});
    //}
    //rendering();

}
)


app.post("/submitincart",(req,res)=>
{
    
    var k=0
    var allinstock=0;
    console.log("submit in cart pressed");
    for(var i=0;i<itemsincart.length;i++)
    {
        async  function checkavail()
        {
            try{
                
                  
                    var isrem=  await inventorymodel.find({prodnum:itemsincart[i],size:sizeincart[i]},{stockremaining:1,_id:0});
                    console.log(" the quan is "+quantityincart)
                    isrem.forEach((st)=>{
                        if(st.stockremaining < parseInt(quantityincart[k])){
                            console.log("Stock not available for item "+itemsincart[k])
                            errormessage=namesincart[k];
                            notinstock.push(namesincart[k]);
                        }else{
                    // console.log( "the number is ",k)
                    allinstock++;
                    console.log("all in stock val is "+allinstock)
                        }
                        k++;
                    // namesincart.push(pri.price)
                    //priceincart.push(pri.price)
                         }
    
                        )

            }
            catch(error)
            {
                console.log(error);
            }
        }
        checkavail();
          
    }
    setTimeout(() => {
        if(allinstock==itemsincart.length){
            res.redirect("/aftersubmit");
           }
           else{
               res.redirect("/notinsto")
           }
    }, 100);
    
})


app.get("/notinsto",(req,res)=>
{
    res.render("notinc",{notinstock:notinstock});
})

app.get("/aftersubmit",(req,res)=>
{

    if(isuserloggedin)
    {
        var b=0;
        for(var i=0;i<itemsincart.length;i++)
        {
            

           
                
                async  function changedb()
                {
                    try{
                            console.log("b value before update is "+b +" itemsin cart is "+itemsincart[b]+" size in cart is "+sizeincart[b]);
                          await inventorymodel.updateOne({prodnum:itemsincart[b],size:sizeincart[b]},
                            {
                               $inc :{'stockremaining':- quantityincart[b++]}
                            })
                            .then(()=>{
                                //console.log("quantity in cart is "+quantityincart[b]);
                              //  b++; 
                                //console.log("b value after b++ is "+b)
                            }
                            )
                            // b++;
                            // console.log("quantity in cart is "+quantityincart[b]);
                                
                            //     console.log("b value after b++ is "+b)
                           
                        
                        }
                        catch(error)
                         {
                            console.log(error);
                        }
                }
                changedb();
               
        
        }
        setTimeout(() => {
            if(b==itemsincart.length)
            {
                // res.render("general",{message:"Your Order is placed succesfully"});
                res.redirect("/genmessage");
            }
        }, 100);
        
        
    }
    else{
        console.log("user has not logged in")
        res.render("general",{message:"User has not logged in"});
    }
    //res.render("cart",{items:itemsincart,name:namesincart,price:priceincart,size:sizeincart,quantity:quantityincart,errormessage:errormessage});
 
})


app.get("/genmessage",(req,res)=>
{
        res.render("general",{message:"Your Order is placed succesfully"});

})


app.post("/startagain",(req,res)=>
{

 currentprod="0";
 addtoc=[];
 namesincart=[];
 priceincart=[];
 itemsincart=[];
 quantityincart=[]
 sizeincart=[]
//  shouldialert=false;
 errormessage="";
 notinstock=[]

 res.redirect("/");
})


app.listen(3000, function(){
    console.log("Server started on port 3000.");
});
